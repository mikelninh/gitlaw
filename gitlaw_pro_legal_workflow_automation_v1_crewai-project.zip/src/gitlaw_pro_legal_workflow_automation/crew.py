import os

from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import (
	FileReadTool,
	OCRTool,
	SerperDevTool,
	ScrapeWebsiteTool
)






@CrewBase
class GitlawProLegalWorkflowAutomationCrew:
    """GitlawProLegalWorkflowAutomation crew"""

    
    @agent
    def intake_agent(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["intake_agent"],
            
            
            tools=[				FileReadTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="internal_openai/gpt-4o",
                
                
            ),
            
        )
        
    
    @agent
    def document_agent(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["document_agent"],
            
            
            tools=[				FileReadTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="internal_openai/gpt-4o",
                
                
            ),
            
        )
        
    
    @agent
    def ocr_translation_agent(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["ocr_translation_agent"],
            
            
            tools=[				OCRTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="internal_openai/gpt-4o",
                
                
            ),
            
        )
        
    
    @agent
    def workflow_recommendation_agent(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["workflow_recommendation_agent"],
            
            
            tools=[				SerperDevTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="internal_openai/gpt-4o",
                
                
            ),
            
        )
        
    
    @agent
    def research_agent(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["research_agent"],
            
            
            tools=[				SerperDevTool(),
				ScrapeWebsiteTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="internal_openai/gpt-4o",
                
                
            ),
            
        )
        
    
    @agent
    def citation_verification_agent(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["citation_verification_agent"],
            
            
            tools=[				SerperDevTool(),
				ScrapeWebsiteTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="internal_openai/gpt-4o",
                
                
            ),
            
        )
        
    
    @agent
    def drafting_agent(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["drafting_agent"],
            
            
            tools=[				FileReadTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="internal_openai/gpt-4o",
                
                
            ),
            
        )
        
    
    @agent
    def memory_agent(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["memory_agent"],
            
            
            tools=[				FileReadTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="internal_openai/gpt-4o",
                
                
            ),
            
        )
        
    

    
    @task
    def process_client_intake(self) -> Task:
        return Task(
            config=self.tasks_config["process_client_intake"],
            markdown=False,
            
            
        )
    
    @task
    def classify_and_organize_documents(self) -> Task:
        return Task(
            config=self.tasks_config["classify_and_organize_documents"],
            markdown=False,
            
            
        )
    
    @task
    def extract_text_and_translate_documents(self) -> Task:
        return Task(
            config=self.tasks_config["extract_text_and_translate_documents"],
            markdown=False,
            
            
        )
    
    @task
    def recommend_next_steps(self) -> Task:
        return Task(
            config=self.tasks_config["recommend_next_steps"],
            markdown=False,
            
            
        )
    
    @task
    def conduct_legal_research(self) -> Task:
        return Task(
            config=self.tasks_config["conduct_legal_research"],
            markdown=False,
            
            
        )
    
    @task
    def verify_legal_citations(self) -> Task:
        return Task(
            config=self.tasks_config["verify_legal_citations"],
            markdown=False,
            
            
        )
    
    @task
    def draft_legal_documents(self) -> Task:
        return Task(
            config=self.tasks_config["draft_legal_documents"],
            markdown=False,
            
            
        )
    
    @task
    def store_approved_content(self) -> Task:
        return Task(
            config=self.tasks_config["store_approved_content"],
            markdown=False,
            
            
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the GitlawProLegalWorkflowAutomation crew"""

        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,

            chat_llm=LLM(model="internal_openai/gpt-4o"),
        )


